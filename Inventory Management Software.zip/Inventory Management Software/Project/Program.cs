﻿using Project;

int option = 0, cloneIndex = 0, index = 0, compCounter = 0, sn = 0, getcompCounter = 0, opt = 0, tempSn = 0, tempPrice = 0;
char choice = ' ';
string brand, model, password, tempBrand, tempModel;
double price = 0;
bool checkBrand = true, checkPrice = true;


        Console.WriteLine();
        Console.Write(" Please enter the number of Computer you want to enter in Inventory : ");
        index = Convert.ToInt32(Console.ReadLine());
        cloneIndex = index;

Computer[] computer = new Computer[index]; 

do{
    Console.WriteLine();
    Console.WriteLine();
    Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
    Console.WriteLine("*    What do you want to do?                                                      *");
    Console.WriteLine("*    1. Enter new Computers (password required)                                   *");
    Console.WriteLine("*    2. Change the information of a particular computer (password required)       *");
    Console.WriteLine("*    3. Display all the Computers by a specific brand                             *");
    Console.WriteLine("*    4. Display all the Computers under a certain a price                         *");
    Console.WriteLine("*    5. Quit                                                                      *");
    Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
    Console.WriteLine();

    Console.Write(" Please enter your choice :)  ");
    option = Convert.ToInt32(Console.ReadLine());
      
    switch (option)
    {   
        case 1:
            {
                Console.Write(" Please enter a password : ");
                password = Console.ReadLine();

                if (password == "password" || password == "Password" || password == "PASSWORD"){
                    do
                    {
                        if (cloneIndex - 1 >= 0){
                            Console.WriteLine();
                            Console.WriteLine(" You can insert " + (cloneIndex) + " computers ");
                            Console.WriteLine();
                            Console.WriteLine();
                            Console.Write(" Please enter the brand of Computer : ");
                            brand = Console.ReadLine();
                            Console.WriteLine();
                            Console.Write(" Please enter the model of Computer : ");
                            model = Console.ReadLine();
                            Console.WriteLine();

                        com1:
                            Console.Write(" Please enter a Serial Number : ");
                            sn = Convert.ToInt32(Console.ReadLine());

                            for (int i = 0; i < compCounter; i++)
                            {
                                if (computer[i].getSn() == sn && computer[i].getBrand() == brand)
                                {
                                    Console.WriteLine( " This Computer is already exist in the inventory " );
                                    goto com1;
                                }
                            }
                            
                            Console.WriteLine();
                            Console.Write(" Please enter the price Computer  : ");
                            price = Convert.ToInt32(Console.ReadLine());

                            computer[compCounter] = new Computer(brand, model, sn, price);

                            Console.WriteLine();
                            compCounter++;
                            cloneIndex--;
                            
                            Console.Write(" Press Y or y to continue: ");
                            choice = Convert.ToChar(Console.ReadLine());
                        }
                    } while (choice == 'Y' || choice == 'y');
                }
                else{
                    Console.Write(" Please enter the password correctly!!! ");
                }
                break;
                
            }
        case 2:
            {
                    for (int i = 0; i < compCounter; i++)
                    {
                        Console.WriteLine("Computer index :" + i);
                    }

                    Console.Write("Please enter the index of Computer : ");
                    getcompCounter = Convert.ToInt32(Console.ReadLine());

                    if (getcompCounter < compCounter){

                        computer[getcompCounter].displayComputer(getcompCounter);
                        do
                        {
                            Console.WriteLine();
                            Console.WriteLine();
                            Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
                            Console.WriteLine("*    What information would you like to change?               *");
                            Console.WriteLine("*    1. Brand                                                 *");
                            Console.WriteLine("*    2. Model                                                 *");
                            Console.WriteLine("*    3. SN                                                    *");
                            Console.WriteLine("*    4. Price                                                 *");
                            Console.WriteLine("*    5. Quit                                                  *");
                            Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
                            
                            Console.Write("Please enter your choice : ");
                            opt = Convert.ToInt32(Console.ReadLine());

                            switch (opt)
                            {
                                case 1:
                                    {
                                        Console.Write(" Please enter the new brand of Computer : ");
                                        tempBrand = Console.ReadLine();
                                        Console.WriteLine();
                                  
                                        computer[getcompCounter].setBrand(tempBrand);
                                        Console.WriteLine();
                                        Console.WriteLine();
                                        computer[getcompCounter].displayComputer(getcompCounter);
                                        break;
                                    }
                                case 2:
                                    {
                                        Console.Write(" Please enter the new Model of Computer : ");
                                        tempModel = Console.ReadLine();
                                        Console.WriteLine();
                                  
                                        computer[getcompCounter].setBrand(tempModel);
                                        Console.WriteLine();
                                        Console.WriteLine();
    
                                        computer[getcompCounter].displayComputer(getcompCounter);
                                        break;
                                    }
                                case 3:
                                    {
                                        Console.Write(" Please enter Serial Number : ");
                                        tempSn = Convert.ToInt32(Console.ReadLine());

                                        computer[getcompCounter].setSn(tempSn);
                                        Console.WriteLine();
                                        Console.WriteLine();

                                        computer[getcompCounter].displayComputer(getcompCounter);
                                        break;
                                    }
                                case 4:
                                    {
                                        Console.Write(" Please enter the price of Computer : ");
                                        tempPrice = Convert.ToInt32(Console.ReadLine());   

                                        computer[getcompCounter].setPrice(tempPrice);
                                        Console.WriteLine();
                                        Console.WriteLine();
                                        computer[getcompCounter].displayComputer(getcompCounter);
                                        break;
                                    }
                            }

                        }while (opt != 5);
                    }
                    else{
                        Console.WriteLine(" You entered wrong Computer Index.... Index must be under " + compCounter );
                    }
                break;
            }
        case 3:
            {
                Console.Write(" Please enter Brand name : ");
                tempBrand = Console.ReadLine();

                for (int i = 0; i < compCounter; i++)
                {
                    if (computer[i].getBrand() == tempBrand){
                        computer[i].displayComputer(i);
                        checkBrand = false;
                    }
                }
                if (checkBrand){
                    Console.WriteLine(" There is no computer in the inventory of this brand. ");
                }           
                break;
            }
        case 4:
            {
                    Console.Write(" Please enter the price of Computer : ");
                    tempPrice = Convert.ToInt32(Console.ReadLine());

                    for (int i = 0; i < compCounter; i++)
                    {
                        if (computer[i].getPrice() < tempPrice){
                            checkPrice = false;
                            computer[i].displayComputer(i);
                        }
                    }
                    if (checkPrice){
                        Console.WriteLine("There is no computer in the inventory under this price $" + tempPrice );
                    }
                break;
            }
        case 5:
            { 
                break;
            }
        default:
            {
                Console.WriteLine(" Value must between 1 to 5 !!! ");
                break;
            }
    }
}while (option != 5);