﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Computer
    {
        public string brand, model;
        public double price;
        public int sn;

        public Computer(string brand, string model, int sn, double price)
        {
            this.brand = brand;
            this.model = model;
            this.sn = sn;
            this.price = price;
        }
        public string getBrand()
        {
            return this.brand;
        }
        public void setBrand(string s)
        {
            this.brand = s;
        }
        public string getModel()
        {
            return this.model;
        }
        public void setModel(string m)
        {
            this.model = m;
        }
        public int getSn()
        {
            return this.sn;
        }
        public void setSn(int sn)
        {
            this.sn = sn;
        }
        public double getPrice()
        {
            return this.price;
        }
        public void setPrice(int p)
        {
            this.price = p;
        }
        public void displayComputer(int index)
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * *");
            Console.WriteLine("*    The computer index is : " + (index) + "       *");
            Console.WriteLine("*    The brand is          : " + this.brand + "    *");
            Console.WriteLine("*    The model is          : " + this.model + "    *");
            Console.WriteLine("*    The sn is             : " + this.sn +  "      *");
            Console.WriteLine("*    The price is          : " + this.price + "    *");
            Console.WriteLine("* * * * * * * * * * * * * * * * * * * * * * * * * *");
        }
    }
}